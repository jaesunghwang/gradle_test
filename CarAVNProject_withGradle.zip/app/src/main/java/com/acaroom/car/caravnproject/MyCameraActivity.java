package com.acaroom.car.caravnproject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.HashMap;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.media.CameraProfile;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MyCameraActivity extends Activity implements OnClickListener,
		SurfaceHolder.Callback, Camera.PictureCallback 
//	, OnCompletionListener {
{
	
	public static final String TAG = "MyCamera";
	
	Button mBtn;
	
	// POINT: ī�޶�� SurfaceView, SurfaceHolder ����
	Camera mCamera;
	SurfaceView mSurfaceView;
	SurfaceHolder mHolder;

	private Parameters mParameters;
	
	// ���� ���� ����
	MediaPlayer mediaPlayer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cameratest);
		
		// POINT: SurfaceView ���ҽ� ����
		mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView1);

		mBtn = (Button) findViewById(R.id.button1);
		mBtn.setOnClickListener(this);
		
		// POINT: SurfaceHolder ����
		mHolder = mSurfaceView.getHolder();
		mHolder.addCallback(this);
		//mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		mHolder.setFixedSize(1024, 768);
		// ������ ����
		mediaPlayer = MediaPlayer.create(this, R.raw.camerashutter);
		
	}

	public void onClick(View v) {
		Log.i(TAG, "onClick");
		if (v.getId() == R.id.button1) {
			Log.i(TAG, "takePicture");
			
			mediaPlayer.start();
			mCamera.takePicture(null, null, this);
		}
	}
	
	// POINT: SurfaceView�� ��Ǿ��� �� ī�޶� ���� �ʱ�ȭ
	public void surfaceCreated(SurfaceHolder arg0) {
		try {
			// TODO: ī�޶� ��ġ�� ���� 
			// PreviewDisplay�� mHolder�� �����Ѵ�
			mCamera = Camera.open();
			mCamera.setPreviewDisplay(mHolder);
			
			setCameraParameters(); // �Ķ���� ���� ����ڸ޼��� ȣ��
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// POINT: Surface������ �˸��� �ݹ�, ������ ������ ǥ���Ѵ� 
	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		// TODO: ī�޶��� �����並 �����Ѵ�
		mCamera.startPreview();
	}

	// POINT: SurfaceHolder�� �ݹ� ��ƾ, ���Ż�Ȳ ��
	public void surfaceDestroyed(SurfaceHolder arg0) {
		finishCamera(); // ����� �޼��� ȣ��
	}

	//POINT: CameraPictureCallback�������̽��� onPictureTaken�� ����
	public void onPictureTaken(byte[] data, Camera camera) {
		Log.i(TAG, "onPictureTaken");
		// �ܺ� ������� ��ġ ���� ���⼭�� DCIM �̿�
		String sdcard_path = Environment.getExternalStorageDirectory()
				.getAbsolutePath();
		Log.i(TAG, "sdcard_path: "+sdcard_path);
		String photo_dir = sdcard_path + "/DCIM/mytest/";
		Log.i(TAG, "photo_dir: "+photo_dir);
		
		File f = new File(photo_dir);
		if(!f.exists()) {
			Log.i(TAG, "have to make photo_dir");
			boolean res = f.mkdir();
			Log.i(TAG, "res: "+res);
		}
		FileOutputStream fos = null;
		String filename = null;
		
		try {
			Calendar cal = Calendar.getInstance();
			
			int yy, mm, dd, hr, mi, ss;
			yy = cal.get(Calendar.YEAR);
			mm = cal.get(Calendar.MONTH);
			dd = cal.get(Calendar.DATE); 
			hr = cal.get(Calendar.HOUR);
			mi = cal.get(Calendar.MINUTE);
			ss = cal.get(Calendar.SECOND);
			String now = new StringBuilder()
            // Month is 0 based so add 1
            .append(yy)
            .append(pad(mm + 1))
            .append(dd).append("-")
            .append(pad(hr))
            .append(pad(mi))
            .append(pad(ss)).toString();
			Log.i(TAG, "now: "+now);
			filename = photo_dir + now +".jpg";
			Log.i(TAG, "filename: "+filename);
			fos = new FileOutputStream(filename);
			fos.write(data);
			fos.close();
			fos = null;
			// POINT: �̵��� �̿��ϵ��� �̵�ĳ�� �׼��� 
			// ��ε�ĳ��Ʈ ��
			Intent photo_intent = new Intent(
					Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
					Uri.parse("file://"+filename));
			sendBroadcast(photo_intent);
			
		} catch (Exception e) {
			e.printStackTrace();
			setResult(RESULT_CANCELED, null);
        	finish();
        	
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				fos = null;
			}
		}
		
		Intent i = new Intent();
		if(filename != null)
			i.putExtra("MY_PIC", filename);
		
		setResult(RESULT_OK, i);
    	finish();	

	}
	
	private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }
	
	// �Ķ���� ���� ����� �޼���
	private void setCameraParameters() {
    	Log.i(TAG, "setCameraParameters ");
        mParameters = mCamera.getParameters();

        mParameters.setPictureSize(640, 480);
        mParameters.setPreviewSize(640, 480);

        String mSceneMode = "auto";
        mParameters.setSceneMode(mSceneMode);

        // Set JPEG quality.
        String jpegQuality = "superfine";
        Log.i(TAG, "jpegQuality:"+jpegQuality);
        mParameters.setJpegQuality(
        		JpegEncodingQualityMappings.getQualityNumber(jpegQuality));

        String colorEffect = "none";
        mParameters.setColorEffect(colorEffect);
        String flashMode = "no_flash";
        mParameters.setFlashMode(flashMode);
        Log.i(TAG, "flashMode:"+flashMode);
        
        String whiteBalance = Parameters.WHITE_BALANCE_AUTO;
        mParameters.setWhiteBalance(whiteBalance);
        Log.i(TAG, "whiteBalance:"+whiteBalance);
        // Set focus mode.
        String mFocusMode = Parameters.FOCUS_MODE_AUTO;
        mParameters.setFocusMode(mFocusMode);
        Log.i(TAG, "mFocusMode:"+mFocusMode);

        mParameters.setFlashMode(Parameters.FLASH_MODE_AUTO);
        mParameters.setFlashMode(Parameters.FOCUS_MODE_AUTO);
        mCamera.setParameters(mParameters);
    }

	
	private void finishCamera() {
		if(mCamera != null) {
			mCamera.stopPreview();
			mCamera.release();
			mCamera = null;
		}
		
		if(mediaPlayer != null) {
			mediaPlayer.stop();
			mediaPlayer.release();
			mediaPlayer=null;
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		finishCamera();
		
	}

}

// JpegEncodingQualityMappings
class JpegEncodingQualityMappings {
    private static final String TAG = "JpegEncodingQualityMappings";
    private static final int DEFAULT_QUALITY = 85;
    private static HashMap<String, Integer> mHashMap =
            new HashMap<String, Integer>();

    static {
        mHashMap.put("normal",    CameraProfile.QUALITY_LOW);
        mHashMap.put("fine",      CameraProfile.QUALITY_MEDIUM);
        mHashMap.put("superfine", CameraProfile.QUALITY_HIGH);
    }

    // Retrieve and return the Jpeg encoding quality number
    // for the given quality level.
    public static int getQualityNumber(String jpegQuality) {
        Integer quality = mHashMap.get(jpegQuality);
        if (quality == null) {
            Log.w(TAG, "Unknown Jpeg quality: " + jpegQuality);
            return DEFAULT_QUALITY;
        }
        return CameraProfile.getJpegEncodingQualityParameter(quality.intValue());
    }
}
