package com.acaroom.car.caravnproject;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.widget.ImageView;

public class ParkingActivity extends Activity {
    /** Called when the activity is first created. */
	final static int CAMERA_RESULT = 0;
	public static final String TAG = "CustomCameraTestActivity";

	ImageView imv;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.parking_activity);

		Intent i = new Intent(this, MyCameraActivity.class);
		startActivityForResult(i, CAMERA_RESULT);
	}

	protected void onActivityResult(
			int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			// Get a reference to the ImageView
			Log.i(TAG, "RESULT_OK");
			String pathName = null;
			Bundle extras = data.getExtras(); 
	        if(extras!= null)	{
	        	pathName = extras.getString("MY_PIC");
	        	Log.i(TAG,"pathName: "+pathName);
	        }
	        else
	        	return;
			
			imv = (ImageView) findViewById(R.id.ReturnedImageView);

			Display currentDisplay = getWindowManager().getDefaultDisplay();
			int dw = currentDisplay.getWidth();
			int dh = currentDisplay.getHeight();

			// Load up the image's dimensions not the image itself
			BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
			bmpFactoryOptions.inJustDecodeBounds = true;
			Bitmap bmp = BitmapFactory.decodeFile(
					pathName, bmpFactoryOptions);

			int heightRatio = (int) Math.ceil(
					bmpFactoryOptions.outHeight	/ (float) dh);
			int widthRatio = (int) Math.ceil(
					bmpFactoryOptions.outWidth / (float) dw);

			Log.i(TAG, "HEIGHTRATIO:" + heightRatio);
			Log.i(TAG, "WIDTHRATIO:" + widthRatio);

			if (heightRatio > 1 && widthRatio > 1) {
				if (heightRatio > widthRatio) {
					// Height ratio is larger, scale according to it
					bmpFactoryOptions.inSampleSize = heightRatio;
				} else {
					// Width ratio is larger, scale according to it
					bmpFactoryOptions.inSampleSize = widthRatio;
				}
			}

			// Decode it for real
			bmpFactoryOptions.inJustDecodeBounds = false;
			bmp = BitmapFactory.decodeFile(
					pathName, bmpFactoryOptions);

			// Display it
			imv.setImageBitmap(bmp);
		}
		else {
			finish();
		}
	}
}